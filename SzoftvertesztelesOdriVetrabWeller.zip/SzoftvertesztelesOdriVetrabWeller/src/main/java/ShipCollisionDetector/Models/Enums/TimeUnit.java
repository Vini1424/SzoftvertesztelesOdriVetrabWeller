package ShipCollisionDetector.Models.Enums;

public enum TimeUnit {
	S, M, H
}
