package ShipCollisionDetector.Models.Enums;

public enum MassUnit {
	G,KG,T,OZ,LB
}
