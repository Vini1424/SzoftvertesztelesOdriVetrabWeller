package ShipCollisionDetector.Models.Enums;

public enum LengthUnit {
	CM,M,KM,IN,FT,YD,MILE,NM
}
