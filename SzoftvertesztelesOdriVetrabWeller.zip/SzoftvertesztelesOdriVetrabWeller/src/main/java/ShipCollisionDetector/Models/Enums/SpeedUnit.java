package ShipCollisionDetector.Models.Enums;

public enum SpeedUnit {
	MS,KMH,MIH,KNOT
}
