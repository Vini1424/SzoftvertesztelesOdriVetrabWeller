package ShipCollisionDetector.Models;

public class ShipTests {

}
